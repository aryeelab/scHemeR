library(testthat)
library(scTools)

test_check("scTools")
