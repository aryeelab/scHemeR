#' scTools: Efficient tools for single cell analyses
#'
#' Functions written by CAL to do cool stuff.
#'
#' @useDynLib scTools
#' @docType package
#' @name scTools
#' @import Rcpp
NULL
