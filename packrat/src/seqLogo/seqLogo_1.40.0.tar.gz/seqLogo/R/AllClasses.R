setClass("pwm", representation(
    pwm="matrix",
    consensus="character",
    ic="numeric",                                                          
    width="numeric",
    alphabet="character"))
